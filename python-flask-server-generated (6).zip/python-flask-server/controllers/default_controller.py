
def add_notifications(message content) -> str:
    return 'do some magic!'
